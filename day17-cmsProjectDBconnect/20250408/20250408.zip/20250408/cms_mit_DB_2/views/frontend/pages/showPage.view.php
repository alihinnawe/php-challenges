<?php var_dump($page); ?>

<h1><?php echo e($page->title); ?></h1>
<div><?php echo e($page->content); ?></div>