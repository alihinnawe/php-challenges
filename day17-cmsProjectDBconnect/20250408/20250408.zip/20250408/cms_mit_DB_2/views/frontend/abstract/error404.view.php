<?php /* <h1>Ich bin die error404.view.php-Datei</h1> */ ?>
<h1>Error 404: Not found</h1>