<!DOCTYPE HTML>
<html lang="de">
	<head>
		<meta charset="UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" href="../styles/simple.css" type="text/css"/>
		<title>Wetter App</title>
	</head>
	<body>
		<header><h4>weather __APP</h4></header>
		<main>
			<?php echo $content; ?>
		</main>
		<footer><p>PHP basics 2025</p></footer>
	</body>
</html>