<?php

require_once __DIR__ . '/db-connect.inc.php';
require_once __DIR__ . '/functions.inc.php';
require_once __DIR__ . '/autoload.inc.php';