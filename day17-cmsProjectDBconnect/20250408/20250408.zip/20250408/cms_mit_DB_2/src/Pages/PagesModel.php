<?php

namespace App\Pages;

class PagesModel {

    public int $id;
    public string $slug;
    public string $title;
    public string $content;
}